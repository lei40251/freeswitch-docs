export default [
  require("/home/homepc/workspace/StudyLab/freeswitch-docs/node_modules/infima/dist/css/default/default.css"),
  require("/home/homepc/workspace/StudyLab/freeswitch-docs/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/home/homepc/workspace/StudyLab/freeswitch-docs/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/home/homepc/workspace/StudyLab/freeswitch-docs/src/css/custom.scss"),
];
