import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/freeswitch/zh-Hans/search/',
    component: ComponentCreator('/freeswitch/zh-Hans/search/', '4cb'),
    exact: true
  },
  {
    path: '/freeswitch/zh-Hans/',
    component: ComponentCreator('/freeswitch/zh-Hans/', '46d'),
    routes: [
      {
        path: '/freeswitch/zh-Hans/',
        component: ComponentCreator('/freeswitch/zh-Hans/', 'b55'),
        routes: [
          {
            path: '/freeswitch/zh-Hans/',
            component: ComponentCreator('/freeswitch/zh-Hans/', 'fe3'),
            routes: [
              {
                path: '/freeswitch/zh-Hans/applications/',
                component: ComponentCreator('/freeswitch/zh-Hans/applications/', '777'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/applications/call-queues/',
                component: ComponentCreator('/freeswitch/zh-Hans/applications/call-queues/', 'ec6'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/applications/conferencing/',
                component: ComponentCreator('/freeswitch/zh-Hans/applications/conferencing/', '4d7'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/applications/fax/',
                component: ComponentCreator('/freeswitch/zh-Hans/applications/fax/', '4f2'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/applications/ivr-menus/',
                component: ComponentCreator('/freeswitch/zh-Hans/applications/ivr-menus/', 'd07'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/applications/utilities/',
                component: ComponentCreator('/freeswitch/zh-Hans/applications/utilities/', '9f7'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/applications/voicemail/',
                component: ComponentCreator('/freeswitch/zh-Hans/applications/voicemail/', 'e40'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/configuration/',
                component: ComponentCreator('/freeswitch/zh-Hans/configuration/', 'b1c'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/configuration/core-settings/',
                component: ComponentCreator('/freeswitch/zh-Hans/configuration/core-settings/', 'f8a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/configuration/module-loading/',
                component: ComponentCreator('/freeswitch/zh-Hans/configuration/module-loading/', '24a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/configuration/xml/',
                component: ComponentCreator('/freeswitch/zh-Hans/configuration/xml/', '822'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/dialplan/',
                component: ComponentCreator('/freeswitch/zh-Hans/dialplan/', 'e39'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/dialplan/dptools/',
                component: ComponentCreator('/freeswitch/zh-Hans/dialplan/dptools/', 'bdd'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/dialplan/public-context/',
                component: ComponentCreator('/freeswitch/zh-Hans/dialplan/public-context/', 'c61'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/dialplan/time-routing/',
                component: ComponentCreator('/freeswitch/zh-Hans/dialplan/time-routing/', '6f8'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/dialplan/xml/',
                component: ComponentCreator('/freeswitch/zh-Hans/dialplan/xml/', '9fa'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/foundations/',
                component: ComponentCreator('/freeswitch/zh-Hans/foundations/', 'b8b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/foundations/getting-started/',
                component: ComponentCreator('/freeswitch/zh-Hans/foundations/getting-started/', 'f48'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/foundations/introduction/',
                component: ComponentCreator('/freeswitch/zh-Hans/foundations/introduction/', 'e3b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/integration/',
                component: ComponentCreator('/freeswitch/zh-Hans/integration/', '502'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/integration/acls/',
                component: ComponentCreator('/freeswitch/zh-Hans/integration/acls/', '87b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/integration/cdr/',
                component: ComponentCreator('/freeswitch/zh-Hans/integration/cdr/', '89b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/integration/event-socket/',
                component: ComponentCreator('/freeswitch/zh-Hans/integration/event-socket/', '38a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/integration/scripting/',
                component: ComponentCreator('/freeswitch/zh-Hans/integration/scripting/', '0de'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/integration/signalwire/',
                component: ComponentCreator('/freeswitch/zh-Hans/integration/signalwire/', '468'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/integration/xml-curl/',
                component: ComponentCreator('/freeswitch/zh-Hans/integration/xml-curl/', 'efa'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/media-and-codecs/',
                component: ComponentCreator('/freeswitch/zh-Hans/media-and-codecs/', '10c'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/media-and-codecs/audio-files/',
                component: ComponentCreator('/freeswitch/zh-Hans/media-and-codecs/audio-files/', 'dbd'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/media-and-codecs/codecs/',
                component: ComponentCreator('/freeswitch/zh-Hans/media-and-codecs/codecs/', '7fe'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/media-and-codecs/handling/',
                component: ComponentCreator('/freeswitch/zh-Hans/media-and-codecs/handling/', '72d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/', 'dbd'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/', '0d2'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_avmd/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_avmd/', '047'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_bert/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_bert/', '130'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_blacklist/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_blacklist/', '13b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_callcenter/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_callcenter/', 'aee'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_cidlookup/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_cidlookup/', '602'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_com_amd/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_com_amd/', '429'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_commands/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_commands/', '169'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_conference/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_conference/', 'c51'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_curl/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_curl/', 'cd0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_cv/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_cv/', '58d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_db/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_db/', '991'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_directory/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_directory/', '379'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_distributor/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_distributor/', '41f'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_dptools/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_dptools/', '784'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_easyroute/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_easyroute/', '1b8'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_enum/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_enum/', 'b2d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_esf/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_esf/', '39d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_esl/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_esl/', 'ffd'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_expr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_expr/', 'ee0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_fifo/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_fifo/', '343'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_fsk/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_fsk/', '34a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_fsv/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_fsv/', 'fc3'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_hash/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_hash/', 'e88'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_httapi/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_httapi/', '4b5'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_http_cache/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_http_cache/', '2ed'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_lcr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_lcr/', 'b75'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_limit/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_limit/', '30d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_nibblebill/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_nibblebill/', '713'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_osp/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_osp/', '742'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_prefix/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_prefix/', '497'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_random/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_random/', 'b2d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_signalwire/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_signalwire/', 'f93'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_sms/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_sms/', 'a1b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_snapshot/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_snapshot/', 'b34'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_spandsp/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_spandsp/', 'cb3'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_spy/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_spy/', '387'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_translate/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_translate/', 'd8d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_valet_parking/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_valet_parking/', 'a8a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_video_filter/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_video_filter/', '55d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_vmd/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_vmd/', '700'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_voicemail_ivr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_voicemail_ivr/', 'a97'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/applications/mod_voicemail/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/applications/mod_voicemail/', '700'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/asr-tts/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/asr-tts/', '44f'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/asr-tts/mod_flite/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/asr-tts/mod_flite/', 'b02'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/asr-tts/mod_pocketsphinx/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/asr-tts/mod_pocketsphinx/', '5ff'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/asr-tts/mod_tts_commandline/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/asr-tts/mod_tts_commandline/', 'cc7'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/', '5fe'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_amr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_amr/', '101'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_amrwb/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_amrwb/', '4da'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_av/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_av/', '87d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_b64/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_b64/', '222'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_bv/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_bv/', '6f0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_codec2/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_codec2/', 'e15'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_com_g729/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_com_g729/', '319'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_g723_1/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_g723_1/', 'be9'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_g729/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_g729/', '662'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_ilbc/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_ilbc/', '3b3'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_openh264/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_openh264/', '265'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_opus/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_opus/', '1a0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_silk/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_silk/', '39e'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_siren/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_siren/', '9a6'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/codecs/mod_yuv/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/codecs/mod_yuv/', 'b27'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/commercial-modules/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/commercial-modules/', '75f'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/data-stores/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/data-stores/', '10c'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/data-stores/mod_hiredis/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/data-stores/mod_hiredis/', '6c6'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/data-stores/mod_mariadb/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/data-stores/mod_mariadb/', 'bd9'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/data-stores/mod_memcache/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/data-stores/mod_memcache/', '40a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/data-stores/mod_mongo/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/data-stores/mod_mongo/', '576'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/data-stores/mod_pgsql/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/data-stores/mod_pgsql/', 'c55'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/data-stores/mod_redis/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/data-stores/mod_redis/', '217'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/dialplans/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/dialplans/', '26a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/dialplans/mod_dialplan_asterisk/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/dialplans/mod_dialplan_asterisk/', '5cf'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/dialplans/mod_dialplan_directory/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/dialplans/mod_dialplan_directory/', '0ef'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/dialplans/mod_dialplan_xml/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/dialplans/mod_dialplan_xml/', '473'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/', 'cef'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_alsa/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_alsa/', 'bce'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_h323/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_h323/', '814'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_loopback/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_loopback/', '6b0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_opal/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_opal/', '96a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_rtc/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_rtc/', 'b93'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_rtmp/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_rtmp/', '2e0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_skinny/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_skinny/', 'e27'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_sofia/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_sofia/', '3f0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/endpoints/mod_verto/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/endpoints/mod_verto/', 'e0f'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/', '701'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_amqp/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_amqp/', '68a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_cdr_csv/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_cdr_csv/', '3df'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_cdr_pg_csv/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_cdr_pg_csv/', '41b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_cdr_sqlite/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_cdr_sqlite/', 'ffd'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_console/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_console/', 'b36'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_erlang_event/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_erlang_event/', '265'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_event_multicast/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_event_multicast/', 'af4'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_event_socket/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_event_socket/', 'c8f'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_fail2ban/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_fail2ban/', '592'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_format_cdr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_format_cdr/', '559'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_graylog2/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_graylog2/', '2f0'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_json_cdr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_json_cdr/', 'b7e'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_logfile/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_logfile/', 'd18'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_odbc_cdr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_odbc_cdr/', '793'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_smpp/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_smpp/', 'd71'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_snmp/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_snmp/', '7e4'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_syslog/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_syslog/', '491'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/event-handlers/mod_xml_cdr/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/event-handlers/mod_xml_cdr/', '752'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/', '182'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_imagick/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_imagick/', '6df'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_local_stream/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_local_stream/', '044'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_native_file/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_native_file/', '24d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_opusfile/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_opusfile/', 'e7b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_png/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_png/', '1ba'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_shell_stream/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_shell_stream/', '092'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_shout/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_shout/', '2f2'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_sndfile/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_sndfile/', 'eb4'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_tone_stream/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_tone_stream/', 'd6c'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_vlc/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_vlc/', 'aa4'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/formats/mod_webm/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/formats/mod_webm/', '2bd'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/', '777'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/mod_basic/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/mod_basic/', '901'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/mod_java/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/mod_java/', '5b8'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/mod_lua/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/mod_lua/', '0e5'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/mod_managed/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/mod_managed/', '539'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/mod_perl/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/mod_perl/', '52b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/mod_python3/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/mod_python3/', 'cc5'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/languages/mod_v8/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/languages/mod_v8/', 'b1a'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/say/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/say/', '2da'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/timers/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/timers/', '16b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/xml-interfaces/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/xml-interfaces/', '7d9'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_ldap/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_ldap/', '13e'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_curl/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_curl/', '998'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_ldap/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_ldap/', 'a49'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_rpc/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_rpc/', '300'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_scgi/',
                component: ComponentCreator('/freeswitch/zh-Hans/module-reference/xml-interfaces/mod_xml_scgi/', '050'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/programming/',
                component: ComponentCreator('/freeswitch/zh-Hans/programming/', '8d8'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/programming/esl-inbound/',
                component: ComponentCreator('/freeswitch/zh-Hans/programming/esl-inbound/', '7d5'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/programming/esl-outbound/',
                component: ComponentCreator('/freeswitch/zh-Hans/programming/esl-outbound/', 'b43'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/programming/event-model/',
                component: ComponentCreator('/freeswitch/zh-Hans/programming/event-model/', '521'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/programming/events-catalog/',
                component: ComponentCreator('/freeswitch/zh-Hans/programming/events-catalog/', 'a40'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/programming/scripting-apis/',
                component: ComponentCreator('/freeswitch/zh-Hans/programming/scripting-apis/', '45b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/recipes/',
                component: ComponentCreator('/freeswitch/zh-Hans/recipes/', '1c6'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/recipes/box-to-box/',
                component: ComponentCreator('/freeswitch/zh-Hans/recipes/box-to-box/', '1bb'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/recipes/click-to-call/',
                component: ComponentCreator('/freeswitch/zh-Hans/recipes/click-to-call/', 'd90'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/recipes/conference-pin/',
                component: ComponentCreator('/freeswitch/zh-Hans/recipes/conference-pin/', '067'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/recipes/did-ivr-voicemail/',
                component: ComponentCreator('/freeswitch/zh-Hans/recipes/did-ivr-voicemail/', '303'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/recipes/ring-group/',
                component: ComponentCreator('/freeswitch/zh-Hans/recipes/ring-group/', '9ad'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/recipes/time-routing/',
                component: ComponentCreator('/freeswitch/zh-Hans/recipes/time-routing/', 'ef3'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/', '9cd'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/channel-variables/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/channel-variables/', '56c'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/cli-and-api/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/cli-and-api/', '694'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/codec-table/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/codec-table/', '7e2'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/glossary/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/glossary/', '971'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/hangup-causes/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/hangup-causes/', '3ba'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/release-notes-enterprise/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/release-notes-enterprise/', 'd02'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/release-notes/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/release-notes/', '3b4'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/signalwire-map/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/signalwire-map/', 'a6e'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/reference/vanilla-config-map/',
                component: ComponentCreator('/freeswitch/zh-Hans/reference/vanilla-config-map/', 'e5d'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/troubleshooting/',
                component: ComponentCreator('/freeswitch/zh-Hans/troubleshooting/', '7b8'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/troubleshooting/audio/',
                component: ComponentCreator('/freeswitch/zh-Hans/troubleshooting/audio/', 'ab8'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/troubleshooting/call-setup/',
                component: ComponentCreator('/freeswitch/zh-Hans/troubleshooting/call-setup/', 'f84'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/troubleshooting/registration/',
                component: ComponentCreator('/freeswitch/zh-Hans/troubleshooting/registration/', 'c40'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/troubleshooting/toolbox/',
                component: ComponentCreator('/freeswitch/zh-Hans/troubleshooting/toolbox/', '877'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/troubleshooting/traces/',
                component: ComponentCreator('/freeswitch/zh-Hans/troubleshooting/traces/', 'f15'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/users-and-endpoints/',
                component: ComponentCreator('/freeswitch/zh-Hans/users-and-endpoints/', 'd5b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/users-and-endpoints/gateways/',
                component: ComponentCreator('/freeswitch/zh-Hans/users-and-endpoints/gateways/', '4a8'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/users-and-endpoints/other/',
                component: ComponentCreator('/freeswitch/zh-Hans/users-and-endpoints/other/', 'e71'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/users-and-endpoints/sip-profiles/',
                component: ComponentCreator('/freeswitch/zh-Hans/users-and-endpoints/sip-profiles/', '397'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/users-and-endpoints/user-directory/',
                component: ComponentCreator('/freeswitch/zh-Hans/users-and-endpoints/user-directory/', '60b'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/users-and-endpoints/verto/',
                component: ComponentCreator('/freeswitch/zh-Hans/users-and-endpoints/verto/', '692'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/users-and-endpoints/webrtc-sip/',
                component: ComponentCreator('/freeswitch/zh-Hans/users-and-endpoints/webrtc-sip/', '200'),
                exact: true,
                sidebar: "manual"
              },
              {
                path: '/freeswitch/zh-Hans/',
                component: ComponentCreator('/freeswitch/zh-Hans/', '7cd'),
                exact: true,
                sidebar: "manual"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
